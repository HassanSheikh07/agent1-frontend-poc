/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import React, { useEffect, useState } from 'react'

import { ConsentCardInfo, DirectLineConnection, SavedTestCase } from './types'
import { buildUserActivity, createConnection, loadAgent2Settings, loadSettings, postActivity } from './connection'
import { extractBetween, extractConsentCardInfo, extractCsvFileName, stringifyActivity } from './activityParsing'
import { generatePrompt, playPrompt, revisePrompt, savePrompt } from './prompts'
import { styles } from './styles'
import { ConsentCardPanel } from './components/ConsentCardPanel'
import { SavedTestCasesPanel } from './components/SavedTestCasesPanel'

function Chat() {
  const [playingTestCaseId, setPlayingTestCaseId] = useState<number | null>(null)
  const [connection, setConnection] = useState<DirectLineConnection | null>(null)
  const [connection2, setConnection2] = useState<DirectLineConnection | null>(null)
  const [status, setStatus] = useState('Connecting to Agent 1...')
  const [instruction, setInstruction] = useState('I want you to ....')
  const [feedback, setFeedback] = useState('')
  const [csvOutput, setCsvOutput] = useState('')
  const [agent2Instruction, setAgent2Instruction] = useState('')
  const [currentTestCaseName, setCurrentTestCaseName] = useState('')
  const [fullResponse, setFullResponse] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [consentCard, setConsentCard] = useState<ConsentCardInfo | null>(null)
  const [savedTestCases, setSavedTestCases] = useState<SavedTestCase[]>([])
  const [selectedSavedTestCase, setSelectedSavedTestCase] = useState<SavedTestCase | null>(null)
  const [currentOutputSaved, setCurrentOutputSaved] = useState(false)

  useEffect(() => {
    let cancelled = false
    let sub1: { unsubscribe: () => void } | null = null
    let sub2: { unsubscribe: () => void } | null = null

    function handleAgent1Activity(activity: any) {
      console.log('Incoming activity from Agent:', activity)
      if (activity?.from?.id === 'frontend-user') return

      const raw = stringifyActivity(activity)
      setFullResponse(previous =>
        previous
          ? previous + '\n\n---------------------- RAW ACTIVITY ----------------------\n\n' + raw
          : raw
      )

      const consent = extractConsentCardInfo(activity)
      if (consent) {
        setConsentCard(consent)
        setIsLoading(false)
        setStatus(`${consent.connectorName} permission required. Click Allow to continue.`)
        return
      }

      if (activity?.attachments?.length > 0) {
        setIsLoading(false)
        setStatus('Agent returned a card/attachment. Check "View full raw Agent 1 response".')
      }

      if (activity?.type === 'message' && activity?.text) {
        setCurrentOutputSaved(false)
        const csv = extractBetween(activity.text, '---CSV START---', '---CSV END---')
        const agentInstruction = extractBetween(activity.text, '---AGENT2 INSTRUCTION START---', '---AGENT2 INSTRUCTION END---')
        const fileName = extractCsvFileName(activity.text)

        if (csv) setCsvOutput(csv)
        if (agentInstruction) setAgent2Instruction(agentInstruction)
        if (fileName) setCurrentTestCaseName(fileName)
        else if (csv) setCurrentTestCaseName('Generated Test Case')

        setIsLoading(false)
        setStatus('Agent 1 response received. Review the generated output.')
      }
    }

    async function connect() {
      try {
        const agent1 = await createConnection(loadSettings())
        if (cancelled) return
        sub1 = agent1.activity$.subscribe(handleAgent1Activity)
        setConnection(agent1)
        setStatus('Connected to Agent 1.')

        try {
          const agent2 = await createConnection(loadAgent2Settings())
          if (!cancelled) {
            sub2 = agent2.activity$.subscribe(activity => console.log('Incoming activity from Agent 2:', activity))
            setConnection2(agent2)
          }
        } catch (agent2Error) {
          console.error('Failed to connect Agent 2:', agent2Error)
        }
      } catch (error) {
        console.error(error)
        setIsLoading(false)
        setStatus('Failed to connect. Check settings.js, app registration, permissions, and connection string.')
      }
    }

    connect()
    return () => {
      cancelled = true
      sub1?.unsubscribe()
      sub2?.unsubscribe()
    }
  }, [])

  async function sendToAgent1(text: string) {
    if (!connection) {
      setStatus('Agent connection is not ready yet.')
      return
    }
    setIsLoading(true)
    setStatus('Sending message to Agent 1...')
    try {
      await postActivity(connection, buildUserActivity(text))
      setStatus('Message sent. Waiting for Agent 1 response...')
    } catch (error) {
      console.error('Failed to send message:', error)
      setIsLoading(false)
      setStatus('Failed to send message to Agent 1. Check browser console.')
    }
  }

  async function sendConsentResponse(action: 'Allow' | 'Cancel') {
    if (!connection || !consentCard) {
      setStatus('Consent card is not ready.')
      return
    }
    const extra: Record<string, any> = { value: action === 'Allow' ? consentCard.allowData : consentCard.cancelData }
    if (consentCard.replyToId) extra.replyToId = consentCard.replyToId

    setIsLoading(true)
    setStatus(`${action} sent. Waiting for Agent 1 to continue...`)
    try {
      await postActivity(connection, buildUserActivity(action, extra))
      setConsentCard(null)
      setStatus(`${action} response sent. Waiting for Agent 1 response...`)
    } catch (error) {
      console.error('Failed to send consent response:', error)
      setIsLoading(false)
      setStatus('Failed to send connector permission response. Check browser console.')
    }
  }

  function resetOutputs() {
    setCsvOutput('')
    setAgent2Instruction('')
    setCurrentTestCaseName('')
    setFullResponse('')
    setConsentCard(null)
    setSelectedSavedTestCase(null)
    setCurrentOutputSaved(false)
  }

  function generateOutput() {
    resetOutputs()
    sendToAgent1(generatePrompt(instruction))
  }

  function sendChanges() {
    setConsentCard(null)
    sendToAgent1(revisePrompt(feedback))
  }

  function getResolvedSavedName() {
    const responseName = extractCsvFileName(`${fullResponse}\n${currentTestCaseName}\n${csvOutput}\n${agent2Instruction}`)
    return responseName || currentTestCaseName || 'Generated Test Case'
  }

  function approveAndSave() {
    setConsentCard(null)
    if (currentOutputSaved) {
      setStatus('The current generated output has already been saved. Generate a new output to save another test case.')
      return
    }

    const savedTestCase: SavedTestCase = {
      id: Date.now(),
      name: getResolvedSavedName(),
      csvContent: csvOutput,
      instruction: agent2Instruction
    }

    setSavedTestCases(previous => [...previous, savedTestCase])
    setSelectedSavedTestCase(savedTestCase)
    setCurrentOutputSaved(true)
    setStatus(`Saved test case "${savedTestCase.name}" to the list.`)

    sendToAgent1(savePrompt)
  }

  async function handlePlaySavedTestCase(testCase: SavedTestCase) {
    if (!connection2) {
      setStatus('Agent 2 connection is not ready yet.')
      return
    }
    setPlayingTestCaseId(testCase.id)
    setIsLoading(true)
    setStatus(`Running saved test case "${testCase.name}" via Agent 2...`)
    try {
      await postActivity(connection2, buildUserActivity(playPrompt(testCase)))
      setStatus(`Agent 2 started running saved test case "${testCase.name}".`)
    } catch (error) {
      console.error('Failed to send play message to Agent 2:', error)
      setStatus('Failed to send play message to Agent 2. Check browser console.')
    } finally {
      setIsLoading(false)
      setPlayingTestCaseId(null)
    }
  }

  const canGenerate = Boolean(connection && instruction.trim())
  const canApprove = Boolean(connection && (csvOutput.trim() || agent2Instruction.trim()))
  const canRevise = Boolean(connection && feedback.trim())

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div>
          <div style={styles.badge}>Computer Use Automation POC</div>
          <h1 style={styles.title}>Agent 1 Test Script Generator</h1>
          <p style={styles.subtitle}>
            Generate CSV test case data, review the Agent 2 execution instruction, revise if needed, and save only after approval.
          </p>
        </div>

        <div style={styles.statusCard}>
          <span style={connection ? styles.statusDotConnected : styles.statusDotWaiting} />
          <div>
            <div style={styles.statusLabel}>Connection Status</div>
            <div style={styles.statusText}>{status}</div>
          </div>
        </div>
      </div>

      <div style={styles.grid}>
        <div style={styles.leftColumn}>
          <div style={styles.card}>
            <h2 style={styles.cardTitle}>User Instruction</h2>
            <p style={styles.cardDescription}>Enter the business scenario or testing request.</p>

            <textarea
              value={instruction}
              onChange={event => setInstruction(event.target.value)}
              style={styles.instructionBox}
              placeholder='Example: Create a customer in F&O and add demo values for all required fields'
            />

            <div style={styles.buttonRow}>
              <button
                onClick={generateOutput}
                disabled={!canGenerate || isLoading}
                style={!canGenerate || isLoading ? styles.primaryButtonDisabled : styles.primaryButton}
              >
                {isLoading ? 'Generating...' : 'Generate Output'}
              </button>
            </div>
          </div>

          <div style={styles.card}>
            <h2 style={styles.cardTitle}>Feedback / Change Request</h2>
            <p style={styles.cardDescription}>Use this if the generated output needs revision before saving.</p>

            <textarea
              value={feedback}
              onChange={event => setFeedback(event.target.value)}
              style={styles.feedbackBox}
              placeholder='Example: Create only one test case row and use placeholders for missing required values.'
            />

            <button
              onClick={sendChanges}
              disabled={!canRevise || isLoading}
              style={!canRevise || isLoading ? styles.secondaryButtonDisabled : styles.secondaryButton}
            >
              Send Changes
            </button>
          </div>

          {consentCard && (
            <ConsentCardPanel card={consentCard} loading={isLoading} onRespond={sendConsentResponse} />
          )}
        </div>

        <div style={styles.rightColumn}>
          <div style={styles.outputCard}>
            <div style={styles.outputHeader}>
              <div>
                <h2 style={styles.cardTitle}>Generated Test Case Preview</h2>
                <p style={styles.cardDescription}>Review the generated CSV and Agent 2 instruction before saving.</p>
              </div>
              <span style={styles.outputTagPurple}>Preview</span>
            </div>

            <div style={styles.previewSection}>
              <div style={styles.previewLabel}>Generated CSV</div>
              <textarea
                value={csvOutput || 'Generate output to preview the CSV test cases.'}
                readOnly
                style={styles.csvBox}
              />

              <div style={styles.previewLabel}>Agent 2 instruction</div>
              <textarea
                value={agent2Instruction || 'Generate output to preview the Agent 2 execution instruction.'}
                readOnly
                style={styles.agentInstructionBox}
              />

              <div style={styles.buttonRow}>
                <button
                  onClick={approveAndSave}
                  disabled={!canApprove || isLoading || currentOutputSaved}
                  style={!canApprove || isLoading || currentOutputSaved ? styles.successButtonDisabled : styles.successButton}
                >
                  {currentOutputSaved ? 'Saved' : 'Approve & Save'}
                </button>
              </div>
            </div>
          </div>

          <SavedTestCasesPanel
            testCases={savedTestCases}
            selected={selectedSavedTestCase}
            playingId={playingTestCaseId}
            onSelect={setSelectedSavedTestCase}
            onPlay={handlePlaySavedTestCase}
            onCloseSelected={() => setSelectedSavedTestCase(null)}
          />

          <details style={styles.detailsBox}>
            <summary style={styles.detailsSummary}>View full raw Agent 1 response</summary>
            <textarea value={fullResponse} readOnly style={styles.rawResponseBox} />
          </details>
        </div>
      </div>
    </div>
  )
}

export default Chat
