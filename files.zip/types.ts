/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

export type ConsentCardInfo = {
  title: string
  connectorName: string
  description: string
  permissions: string
  allowData: any
  cancelData: any
  replyToId?: string
}

export type SavedTestCase = {
  id: number
  name: string
  csvContent: string
  instruction: string
}

/** Minimal shape of the DirectLine-style connection exposed by Copilot Studio web chat. */
export type DirectLineConnection = {
  activity$: {
    subscribe: (next: (activity: any) => void) => { unsubscribe: () => void }
  }
  postActivity: (activity: any) => {
    subscribe: (next: () => void, error: (err: any) => void) => void
  }
}
