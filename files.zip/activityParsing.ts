/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { ConsentCardInfo } from './types'

/** Trimmed text between two markers, or '' if either marker is missing. */
export function extractBetween(text: string, startMarker: string, endMarker: string): string {
  if (!text) return ''
  const start = text.indexOf(startMarker)
  const end = text.indexOf(endMarker)
  if (start === -1 || end === -1 || end <= start) return ''
  return text.substring(start + startMarker.length, end).trim()
}

/** Pulls the script / CSV file name out of bot text, tolerating markdown and escaped newlines. */
export function extractCsvFileName(text: string): string {
  if (!text) return ''
  const clean = text.replace(/\\n/g, '\n').replace(/\*\*/g, '')
  const match =
    clean.match(/Script Name:\s*([^\n\r]+)/i) || clean.match(/CSV File Name:\s*([^\n\r]+)/i)
  return match?.[1] ? match[1].replace(/["',]+$/g, '').trim() : ''
}

export function stringifyActivity(activity: any): string {
  try {
    return JSON.stringify(activity, null, 2)
  } catch {
    return String(activity)
  }
}

// Adaptive-card containers, in the traversal order each walk expects.
const TEXT_CHILD_KEYS = ['inlines', 'body', 'items', 'columns', 'actions']
const ACTION_CHILD_KEYS = ['actions', 'body', 'items', 'columns']

function childrenOf(node: any, keys: string[]): any[] {
  return keys.flatMap(key => (Array.isArray(node?.[key]) ? node[key] : []))
}

/** Recursively gathers every text/altText string in a card, in document order. */
export function collectTextFromCard(node: any): string[] {
  if (!node || typeof node !== 'object') return []
  const texts: string[] = []
  if (typeof node.text === 'string') texts.push(node.text)
  if (typeof node.altText === 'string') texts.push(node.altText)
  for (const child of childrenOf(node, TEXT_CHILD_KEYS)) texts.push(...collectTextFromCard(child))
  return texts
}

/** Finds the `data` payload of an Action.Submit whose title matches (case-insensitive). */
export function findSubmitActionData(node: any, title: string): any {
  if (!node || typeof node !== 'object') return null
  if (
    node.type === 'Action.Submit' &&
    typeof node.title === 'string' &&
    node.title.toLowerCase() === title.toLowerCase()
  ) {
    return node.data || null
  }
  for (const child of childrenOf(node, ACTION_CHILD_KEYS)) {
    const found = findSubmitActionData(child, title)
    if (found) return found
  }
  return null
}

function detectConnectorName(texts: string[]): string {
  const lower = texts.map(t => t.toLowerCase())
  if (lower.includes('sharepoint')) return 'SharePoint'
  if (lower.some(t => t.includes('dataverse'))) return 'Dataverse'
  if (lower.some(t => t.includes('power automate'))) return 'Power Automate'
  return 'Connector'
}

/** Builds a ConsentCardInfo from a `connectors/consentCard` activity, or null if it isn't one. */
export function extractConsentCardInfo(activity: any): ConsentCardInfo | null {
  if (activity?.name !== 'connectors/consentCard') return null

  const content = activity?.attachments?.find(
    (item: any) => item?.contentType === 'application/vnd.microsoft.card.adaptive'
  )?.content
  if (!content) return null

  const texts = collectTextFromCard(content)

  return {
    title: texts.find(t => t.includes('Connect to continue')) || 'Connect to continue',
    connectorName: detectConnectorName(texts),
    description:
      texts.find(t => t.includes("I'll use your credentials")) ||
      'Connector permission is required to continue.',
    permissions:
      texts.find(t => t.includes('Create file')) ||
      texts.find(t => t.includes('This connection can')) ||
      'This connector needs permission to continue.',
    allowData:
      findSubmitActionData(content, 'Allow') || { action: 'Allow', id: 'submit', shouldAwaitUserInput: true },
    cancelData:
      findSubmitActionData(content, 'Cancel') || { action: 'Cancel', id: 'submit', shouldAwaitUserInput: true },
    replyToId: activity?.id
  }
}
