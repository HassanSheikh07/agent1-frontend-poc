/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { CopilotStudioClient, CopilotStudioWebChat } from '@microsoft/agents-copilotstudio-client'

import { acquireToken } from './acquireToken'
import { SampleConnectionSettings } from './settings'
import { DirectLineConnection } from './types'

const WEBCHAT_SETTINGS = { showTyping: true }
const FRONTEND_USER = { id: 'frontend-user', name: 'Frontend User', role: 'user' }

/** Loads Agent 1 settings, applying the default authority; falls back to blanks if settings.js is missing. */
export function loadSettings(): SampleConnectionSettings {
  try {
    const settings = new SampleConnectionSettings()
    if (!settings.authority) settings.authority = 'https://login.microsoftonline.com'
    return settings
  } catch (error) {
    console.error(
      error + '\nsettings.js Not Found. Rename settings.EXAMPLE.js to settings.js and fill out necessary fields'
    )
    return {
      appClientId: '',
      tenantId: '',
      environmentId: '',
      schemaName: '',
      directConnectUrl: ''
    } as SampleConnectionSettings
  }
}

/** Loads Agent 2 settings, pointing directConnectUrl at the secondary agent. */
export function loadAgent2Settings(): SampleConnectionSettings {
  const settings = new SampleConnectionSettings()
  settings.directConnectUrl = settings.directConnectUrl2 || ''
  return settings
}

/** Authenticates and opens a web chat connection for the given settings. */
export async function createConnection(settings: SampleConnectionSettings): Promise<DirectLineConnection> {
  const token = await acquireToken(settings)
  const client = new CopilotStudioClient(settings, token)
  return CopilotStudioWebChat.createConnection(client, WEBCHAT_SETTINGS) as unknown as DirectLineConnection
}

/** Standard user message activity; `extra` merges in fields like `value` or `replyToId`. */
export function buildUserActivity(text: string, extra: Record<string, any> = {}): any {
  return { type: 'message', from: FRONTEND_USER, text, textFormat: 'plain', locale: 'en-US', ...extra }
}

/** Posts an activity, resolving once the send is acknowledged and rejecting on error. */
export function postActivity(connection: DirectLineConnection, activity: any): Promise<void> {
  return new Promise((resolve, reject) => {
    connection.postActivity(activity).subscribe(() => resolve(), reject)
  })
}
