/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import React from 'react'

import { SavedTestCase } from '../types'
import { styles } from '../styles'

type Props = {
  testCases: SavedTestCase[]
  selected: SavedTestCase | null
  playingId: number | null
  onSelect: (testCase: SavedTestCase) => void
  onPlay: (testCase: SavedTestCase) => void
  onCloseSelected: () => void
}

export function SavedTestCasesPanel({ testCases, selected, playingId, onSelect, onPlay, onCloseSelected }: Props) {
  return (
    <div style={styles.outputCard}>
      <div style={styles.outputHeader}>
        <div>
          <h2 style={styles.cardTitle}>Saved Test Cases</h2>
          <p style={styles.cardDescription}>Each approved save creates a row you can run later.</p>
        </div>
        <span style={styles.outputTag}>Runs</span>
      </div>

      <div style={styles.savedList}>
        {testCases.length === 0 ? (
          <div style={styles.emptyState}>No saved test cases yet. Approve & Save to create one.</div>
        ) : (
          testCases.map(testCase => {
            const isPlaying = playingId === testCase.id
            return (
              <div
                key={testCase.id}
                style={styles.savedRow}
                onClick={() => onSelect(testCase)}
                role='button'
                tabIndex={0}
                onKeyDown={event => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault()
                    onSelect(testCase)
                  }
                }}
              >
                <div style={styles.savedRowName}>{testCase.name}</div>
                <button
                  onClick={event => {
                    event.stopPropagation()
                    onPlay(testCase)
                  }}
                  style={isPlaying ? styles.playButtonLoading : styles.playButton}
                  disabled={isPlaying}
                  type='button'
                >
                  {isPlaying ? '⏳' : '▶'}
                </button>
              </div>
            )
          })
        )}
      </div>

      {selected && (
        <div style={styles.detailCard}>
          <div style={styles.outputHeader}>
            <div>
              <h2 style={styles.cardTitle}>Selected Saved Case</h2>
              <p style={styles.cardDescription}>{selected.name}</p>
            </div>
            <button type='button' onClick={onCloseSelected} style={styles.closeButton}>
              ✕
            </button>
          </div>

          <div style={styles.previewLabel}>Name</div>
          <div style={styles.detailValue}>{selected.name}</div>

          <div style={styles.previewLabel}>CSV Preview</div>
          <textarea value={selected.csvContent} readOnly style={styles.detailTextArea} />

          <div style={styles.previewLabel}>Agent 2 Instruction</div>
          <textarea value={selected.instruction} readOnly style={styles.detailTextArea} />
        </div>
      )}
    </div>
  )
}
