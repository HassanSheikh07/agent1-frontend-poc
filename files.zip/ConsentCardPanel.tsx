/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import React from 'react'

import { ConsentCardInfo } from '../types'
import { styles } from '../styles'

type Props = {
  card: ConsentCardInfo
  loading: boolean
  onRespond: (action: 'Allow' | 'Cancel') => void
}

export function ConsentCardPanel({ card, loading, onRespond }: Props) {
  return (
    <div style={styles.consentCard}>
      <div style={styles.consentIcon}>!</div>
      <h2 style={styles.consentTitle}>{card.title}</h2>
      <p style={styles.consentDescription}>
        Agent 1 needs permission to use <strong>{card.connectorName}</strong> before it can continue the save step.
      </p>
      <p style={styles.consentDescription}>{card.description}</p>

      <div style={styles.permissionBox}>
        <div style={styles.permissionLabel}>Permission request</div>
        <div style={styles.permissionText}>{card.permissions}</div>
      </div>

      <div style={styles.buttonRow}>
        <button
          onClick={() => onRespond('Allow')}
          disabled={loading}
          style={loading ? styles.successButtonDisabled : styles.successButton}
        >
          Allow
        </button>
        <button
          onClick={() => onRespond('Cancel')}
          disabled={loading}
          style={loading ? styles.secondaryButtonDisabled : styles.cancelButton}
        >
          Cancel
        </button>
      </div>
    </div>
  )
}
