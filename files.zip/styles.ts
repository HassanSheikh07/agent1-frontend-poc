/**
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import React from 'react'

const MONO = 'Consolas, Monaco, monospace'

const column: React.CSSProperties = { display: 'flex', flexDirection: 'column', gap: '20px' }

const cardBase: React.CSSProperties = {
  borderRadius: '20px',
  padding: '22px',
  border: '1px solid #e2e8f0',
  boxShadow: '0 18px 45px rgba(15,23,42,0.08)'
}

const buttonBase: React.CSSProperties = {
  border: 'none',
  borderRadius: '12px',
  padding: '12px 18px',
  color: '#ffffff',
  fontWeight: 800,
  cursor: 'pointer'
}

const disabledButton: React.CSSProperties = { ...buttonBase, background: '#94a3b8', cursor: 'not-allowed' }

const button = (background: string, boxShadow?: string): React.CSSProperties => ({
  ...buttonBase,
  background,
  ...(boxShadow ? { boxShadow } : {})
})

const input = (extra: React.CSSProperties): React.CSSProperties => ({
  width: '100%',
  resize: 'vertical',
  boxSizing: 'border-box',
  border: '1px solid #cbd5e1',
  borderRadius: '14px',
  padding: '14px',
  outline: 'none',
  ...extra
})

const tagBase: React.CSSProperties = { padding: '7px 10px', borderRadius: '999px', fontWeight: 800, fontSize: '12px' }

const dotBase: React.CSSProperties = { width: '14px', height: '14px', borderRadius: '50%' }

const playBase: React.CSSProperties = {
  border: 'none',
  borderRadius: '999px',
  width: '40px',
  height: '40px',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 900
}

export const styles: { [key: string]: React.CSSProperties } = {
  page: {
    minHeight: '100vh',
    width: '100vw',
    boxSizing: 'border-box',
    background: 'linear-gradient(135deg, #eef4ff 0%, #f8fafc 45%, #eefdf8 100%)',
    padding: '28px',
    fontFamily: 'Inter, Segoe UI, Arial, sans-serif',
    color: '#0f172a',
    overflowY: 'auto'
  },
  header: {
    maxWidth: '1400px',
    margin: '0 auto 24px auto',
    display: 'flex',
    justifyContent: 'space-between',
    gap: '24px',
    alignItems: 'center'
  },
  badge: {
    display: 'inline-block',
    padding: '7px 12px',
    borderRadius: '999px',
    background: '#dbeafe',
    color: '#1d4ed8',
    fontWeight: 700,
    fontSize: '12px',
    letterSpacing: '0.4px',
    textTransform: 'uppercase'
  },
  title: { margin: '14px 0 8px 0', fontSize: '34px', lineHeight: 1.1, fontWeight: 800, color: '#0f172a' },
  subtitle: { margin: 0, fontSize: '15px', color: '#475569', maxWidth: '720px' },
  statusCard: {
    minWidth: '310px',
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    background: 'rgba(255,255,255,0.92)',
    border: '1px solid #e2e8f0',
    boxShadow: '0 10px 30px rgba(15,23,42,0.08)',
    borderRadius: '18px',
    padding: '16px'
  },
  statusDotConnected: { ...dotBase, background: '#22c55e', boxShadow: '0 0 0 6px rgba(34,197,94,0.15)' },
  statusDotWaiting: { ...dotBase, background: '#f59e0b', boxShadow: '0 0 0 6px rgba(245,158,11,0.15)' },
  statusLabel: { fontSize: '12px', color: '#64748b', fontWeight: 700, textTransform: 'uppercase' },
  statusText: { marginTop: '4px', color: '#0f172a', fontSize: '14px', fontWeight: 600 },
  grid: { maxWidth: '1400px', margin: '0 auto', display: 'grid', gridTemplateColumns: '420px 1fr', gap: '24px' },
  leftColumn: column,
  rightColumn: column,
  card: { ...cardBase, background: 'rgba(255,255,255,0.96)' },
  outputCard: { ...cardBase, background: 'rgba(255,255,255,0.98)' },
  consentCard: {
    background: '#ffffff',
    borderRadius: '20px',
    padding: '22px',
    border: '2px solid #bfdbfe',
    boxShadow: '0 18px 45px rgba(37,99,235,0.16)'
  },
  consentIcon: {
    width: '34px',
    height: '34px',
    borderRadius: '50%',
    background: '#dbeafe',
    color: '#1d4ed8',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: 900,
    marginBottom: '12px'
  },
  consentTitle: { margin: 0, fontSize: '20px', fontWeight: 900, color: '#0f172a' },
  consentDescription: { margin: '8px 0 0 0', fontSize: '14px', color: '#475569', lineHeight: 1.5 },
  permissionBox: { marginTop: '14px', background: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: '14px', padding: '12px' },
  permissionLabel: { fontSize: '12px', fontWeight: 800, color: '#475569', textTransform: 'uppercase', marginBottom: '6px' },
  permissionText: { fontSize: '13px', color: '#0f172a', lineHeight: 1.5, whiteSpace: 'pre-wrap' },
  cardTitle: { margin: 0, fontSize: '18px', fontWeight: 800, color: '#0f172a' },
  cardDescription: { margin: '6px 0 14px 0', fontSize: '13px', color: '#64748b', lineHeight: 1.5 },
  instructionBox: input({ minHeight: '145px', fontSize: '14px', background: '#f8fafc', color: '#0f172a' }),
  feedbackBox: input({ minHeight: '120px', fontSize: '14px', background: '#f8fafc', color: '#0f172a' }),
  buttonRow: { display: 'flex', gap: '10px', marginTop: '14px', flexWrap: 'wrap' },
  primaryButton: button('linear-gradient(135deg, #2563eb, #1d4ed8)', '0 10px 20px rgba(37,99,235,0.25)'),
  primaryButtonDisabled: disabledButton,
  successButton: button('linear-gradient(135deg, #16a34a, #15803d)', '0 10px 20px rgba(22,163,74,0.25)'),
  successButtonDisabled: disabledButton,
  secondaryButton: button('linear-gradient(135deg, #7c3aed, #6d28d9)', '0 10px 20px rgba(124,58,237,0.25)'),
  secondaryButtonDisabled: disabledButton,
  cancelButton: button('#64748b'),
  outputHeader: { display: 'flex', justifyContent: 'space-between', gap: '16px', alignItems: 'flex-start' },
  outputTag: { ...tagBase, background: '#dcfce7', color: '#166534' },
  outputTagPurple: { ...tagBase, background: '#ede9fe', color: '#5b21b6' },
  savedList: { marginTop: '14px', display: 'flex', flexDirection: 'column', gap: '10px' },
  savedRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: '12px',
    padding: '12px 14px',
    borderRadius: '14px',
    border: '1px solid #e2e8f0',
    background: '#f8fafc',
    cursor: 'pointer'
  },
  savedRowName: { fontSize: '14px', fontWeight: 700, color: '#0f172a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  playButton: { ...playBase, background: 'linear-gradient(135deg, #2563eb, #1d4ed8)', cursor: 'pointer', boxShadow: '0 8px 16px rgba(37,99,235,0.24)' },
  playButtonLoading: { ...playBase, background: '#94a3b8', cursor: 'not-allowed', boxShadow: 'none' },
  previewSection: { marginTop: '14px', display: 'flex', flexDirection: 'column', gap: '10px' },
  previewLabel: { fontSize: '12px', fontWeight: 800, color: '#64748b', textTransform: 'uppercase' },
  detailCard: { marginTop: '14px', border: '1px solid #e2e8f0', borderRadius: '14px', padding: '14px', background: '#f8fafc' },
  detailValue: { fontSize: '14px', fontWeight: 700, color: '#0f172a', whiteSpace: 'pre-wrap', marginBottom: '12px' },
  detailTextArea: input({ minHeight: '140px', fontSize: '13px', lineHeight: 1.5, fontFamily: MONO, background: '#ffffff', color: '#0f172a' }),
  closeButton: {
    border: 'none',
    borderRadius: '999px',
    width: '34px',
    height: '34px',
    background: '#e2e8f0',
    color: '#334155',
    fontSize: '16px',
    fontWeight: 800,
    cursor: 'pointer'
  },
  emptyState: { padding: '16px', borderRadius: '14px', border: '1px dashed #cbd5e1', background: '#f8fafc', color: '#64748b', textAlign: 'center', fontSize: '14px' },
  csvBox: input({ minHeight: '230px', fontSize: '13px', lineHeight: 1.5, fontFamily: MONO, background: '#0f172a', color: '#e2e8f0' }),
  agentInstructionBox: input({ minHeight: '260px', fontSize: '14px', lineHeight: 1.6, background: '#f8fafc', color: '#0f172a' }),
  detailsBox: { background: 'rgba(255,255,255,0.90)', borderRadius: '18px', border: '1px solid #e2e8f0', padding: '16px', boxShadow: '0 10px 30px rgba(15,23,42,0.06)' },
  detailsSummary: { cursor: 'pointer', fontWeight: 800, color: '#334155' },
  rawResponseBox: input({ marginTop: '14px', minHeight: '260px', fontSize: '12px', lineHeight: 1.5, fontFamily: MONO, background: '#020617', color: '#a7f3d0' })
}
